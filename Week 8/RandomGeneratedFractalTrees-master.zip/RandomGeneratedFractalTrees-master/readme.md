This is a random tree generator that I programmed in C++ using OpenGL and SDL.

Link to visualization: http://www.youtube.com/watch?v=agoqIy91dCo